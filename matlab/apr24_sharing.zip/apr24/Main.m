clear; close all; clc;
global w0 %global variable
w0=1;
tstart=0;
u0=[0.1;0];
tfinal=200;
[t,u]=ode45(@(t,u) RightHandSide(t,u),[tstart,tfinal],u0);
%ode45(@(t,u) RightHandSide(t,u),[tstart,tfinal],u0)

x=u(:,1);
v=u(:,2);

te=linspace(tstart,tfinal,200);
xe=interp1(t,x,te,"spline");
ve=interp1(t,v,te,"spline"); %since t is not an evenly
%spaced list

tdiff=diff(t); %in an array, calculates the difference between neighbo
%uring elements
plot(tdiff)
plot(te,xe);

%% Event finding
clear; close all; clc;
global w0 %global variable
w0=1;
tstart=0;
u0=[0;0.1];
tfinal=20;
options=odeset('Events',@Events,'RelTol',1E-8);
[t,u,te,ue,ie]=ode45(@(t,u) RightHandSide(t,u),[tstart,tfinal],u0,options);
%ode45(@(t,u) RightHandSide(t,u),[tstart,tfinal],u0)

t1=te(ie==1);%time instances
x1=ue(ie==1,1);
v1=ue(ie==1,2);

t2=te(ie==2);%time instances
x2=ue(ie==2,1);
v2=ue(ie==2,2);

plot(t,u(:,1),'g-',t1,x1,'rx',t2,x2,'bx')